package com.example.deal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DealApplicationTests {

	@Test
	void contextLoads() {
	}

}
